= = = = = = = = = = TamaGoPy = = = = = = =

Ce jeu est un Tamagotchi se déroulant en ligne
de commandes (Invite de Commandes de Windows)
Il est entièrement programmé en Python, ce qui
lui donne une très bonne optimisation et une
utilisation quasi-nulle des performances de votre
PC
Notez bien que seuls les raccourcis sont développés
en langage BATCH, pour pouvoir être compatible avec
n'importe quel système d'exploitation.

- Ce logiciel inclut également une version embarquée
de python 3.7 (Portable)

============== Dèrnières Mises à Jour

- vAlpha 1.3.2

TamaGoPy est désormais pourvu d'un système de
sauvegarde, vous permettant ainsi de continuer
votre partie plus tard !
Il n'y a pas de sauvegarde auto, impliquant
que chaque sauvegarde est faite avec votre
accord, sauf dans un cas exeptionnel (la
manière dont est codé le logiciel implique
la sauvegarde en début de partie)

Téléchargez le changelog complet
sur le site officiel de TamaGoPy !

============= Démarrage

- Extrayez cette archive
- Lancer l'éxécutable "TamaGoPy.exe"

Il n'y a pas besoin d'installation préalable. Le jeu
est donc complètement portable et peut être transféré
sur une mémoire extrerne. (à condition d'utiliser le
même système d'exploitation : Windows, MacOs X ou Linux)
