#!/bin/bash

cd bin
clear
python3 tamago.py
