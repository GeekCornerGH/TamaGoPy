= = = = = = = = = = = TamaGoPy = = = = = = = = = = = = =

Tamagopy est un jeu (un tamagotchi) programmé en Python.
Il se déroule dans le terminal, ce qui lui donne un air
un peu vieillot. C'est le but

========== Dèrnières Mises à Jour

Version Alpha 1.3.2

TamagoPy dispose désormais d'un système de sauvegarde,
rendant les parties plus intéressantes et sauvegardables,
vous permettant logiquement de reprendre votre partile là
où vous vous en êtes arrêtés.
Sachez que le jeu vous demande toujours votre avis avant
de faire une sauvegarde du jeu, et que la sauvegarde auto
n'a lieu que quand c'est obligatoire ou imposée par la
façon dont a été codé le jeu (c'est à dire en début de partie,
l'orsque vous démarrez le jeu et que vous demandez à recréer
une partie.

============Installation et Démarrage

Le jeu est installable d'une façon très simple. Il suffit
d'extraire cette archive.
Une fois extraite, vous pouvez simplement lancer le jeu
en double-cliquant sur le fichier "run.sh" et ensuite sur
"Lancer dans un terminal"
